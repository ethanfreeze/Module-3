#Print command
print('hello world')

#List Variable
counties = ["Arapahoe","Denver","Jefferson"]

#list appendix
print(counties[0])
print(counties[-1])
print(counties[1])
print(counties[0:2])
print(len(counties))

#list changing
counties.append('El Paso')
print(counties)
counties.remove('El Paso')
print(counties)
counties.insert(2,'El Paso')
print(counties)
counties.pop(2)
print(counties)
counties[2] = 'El Paso'
print(counties)

#Tuple Variable
counties_tuple = ("Arapahoe","Denver","Jefferson")
len(counties_tuple)
counties_tuple[1]

#Dictionaries
counties_dict = {}
counties_dict["Arapahoe"] = 422829
counties_dict["Denver"] = 463353
counties_dict["Jefferson"] = 432438

print(counties_dict)

#length, list, keys, and values for dic
len(counties_dict)
counties_dict.items()
counties_dict.keys()
counties_dict.values()

#Get values from dic
counties_dict['Arapahoe'] 

counties_dict.get("Arapahoe")  

print(counties_dict['Arapahoe'])  

print(counties_dict.get("Arapahoe")) 

#More dic practice
voting_data = []
voting_data.append({"county":"Arapahoe", "registered_voters": 422829})
voting_data.append({"county":"Denver", "registered_voters": 463353})
voting_data.append({"county":"Jefferson", "registered_voters": 432438})

voting_data

voting_data.append({'county':'El Paso','registered_voters': 461149})
print('Voting data length', len(voting_data))
voting_data.pop(0)
print(voting_data)

voting_data.insert(2,{'county':'Denver', 'registered_voters':463353})
voting_data.insert(4,{'county':'Arapahoe', 'registered_voters':422829})
voting_data.pop(0)
voting_data.pop(2)
voting_data.insert(0,{'county':'El Paso', 'registered_voters':461149})
print(voting_data)

#Voting input
# How many votes did you get?
my_votes = int(input("How many votes did you get in the election? "))
#  Total votes in the election
total_votes = int(input("What is the total votes in the election? "))
# Calculate the percentage of votes you received.
percentage_votes = (my_votes / total_votes) * 100
print("I received " + str(percentage_votes)+"% of the total votes.")

#if else
counties = ["Arapahoe","Denver","Jefferson"]
if counties[1] == 'Denver':
    print(counties[1])

temperature = int(input("What is the temperature outside? "))

if temperature > 80:
    print("Turn on the AC.")
else:
    print("Open the windows.")

# What is the score?
score = int(input("What is your test score? "))

# Determine the grade.
if score >= 90:
    print('Your grade is an A.')
elif score >= 80:
    print('Your grade is a B.')
elif score >= 70:
    print('Your grade is a C.')
elif score >= 60:
    print('Your grade is a D.')
else:
    print('Your grade is an F.')

if "El Paso" in counties:
    print("El Paso is in the list of counties.")
else:
    print("El Paso is not the list of counties.")

#Operators
counties = ["Arapahoe","Denver","Jefferson"]
if "El Paso" in counties:
    print("El Paso is in the list of counties.")
else:
    print("El Paso is not the list of counties.")

if "Arapahoe" in counties and "El Paso" in counties:
    print("Arapahoe and El Paso are in the list of counties.")
else:
    print("Arapahoe or El Paso is not in the list of counties.")

if "Arapahoe" in counties or "El Paso" in counties:
    print("Arapahoe or El Paso is in the list of counties.")
else:
    print("Arapahoe and El Paso are not in the list of counties.")

#Loops
x = 0
while x <= 5:
    print(x)
    x = x + 1

for county in counties:
    print(county)

numbers = [0, 1, 2, 3, 4]
for num in numbers:
    print(num)

for num in range(5):
    print(num)

for i in range(len(counties)):
    print(counties[i])

counties_dict = {"Arapahoe": 422829, "Denver": 463353, "Jefferson": 432438}
for county in counties_dict:
    print(county)
for county in counties_dict.keys():
    print(county)

for voters in counties_dict.values():
    print(voters)

for county in counties_dict:
    print(counties_dict[county])
for county in counties_dict:
    print(counties_dict.get(county))

for county, voters in counties_dict.items():
    print(county, voters)

voting_data = [{"county":"Arapahoe", "registered_voters": 422829},
                {"county":"Denver", "registered_voters": 463353},
                {"county":"Jefferson", "registered_voters": 432438}]

for county_dict in voting_data:
    print(county_dict)

for i in range(len(voting_data)):

      print(voting_data[i]['county'])

for county_dict in voting_data:
    print(county_dict['county'])
for county_dict in voting_data:
    print(county_dict['registered_voters'])

#Nested loop
for county_dict in voting_data:
    for value in county_dict.values():
        print(value)

#multi line f string 
candidate_votes = int(input("How many votes did the candidate get in the election? "))
total_votes = int(input("What is the total number of votes in the election? "))
message_to_candidate = (
    f"You received {candidate_votes} number of votes. "
    f"The total number of votes in the election was {total_votes}. "
    f"You received {candidate_votes / total_votes * 100}% of the total votes.")

print(message_to_candidate)

#Skill Drill F formatting
""" counties_dict = {"Arapahoe": 422829, "Denver": 463353, "Jefferson": 432438}

for key in counties_dict:
    for value in counties_dict.values():
        voteNum = value
        int(voteNum)
        print(voteNum) """


#Skill Drill Counties
for county, voters in counties_dict.items():
    print(f'{county} county has {voters} registered voters')

# Skill drill Math expressions
one = 5+2*3
two = 8//5-3
three = 8+22*2-4
four = 16-3/2+7-1
five = 3**3%5
six = 5+9*3/2-4

seven = (5 + 2) * 3
eight = (8 // 5) - 3
nine = 8 + (22 * (2 - 4))
ten = 16 - 3 / (2 + 7) - 1
eleven = 3 ** (3 % 5)

print(one,'\n',two,'\n',three,'\n',four,'\n',five,'\n',six,'\n',seven,'\n',eight,'\n',nine,'\n',ten,'\n',eleven)

